<a href="https://github.com/openantz/antz/archive/master.zip">DOWNLOAD - MSW application</a> by clicking 'Download ZIP' button (upper right.)

<a href="https://github.com/openantz/antz/archive/osx.zip">DOWNLOAD - OSX application</a> by selecting 'Branch: osx' (upper left.)</a>

Command overview 'cheatsheet.txt' is in the 'doc' folder.

Doc folder also contains release notes, LICENSE.txt and links to other resources.

You can find sample datasets at ANTz homepage: <a href="http://openantz.com">http://openantz.com</a>
